include brackets in expressions anuj made
merge my last version(8) with anuj's last version
following functions are changed to handle segmentation fault
addnode
makechild
(use them from vipin's final version)
don't change vipin's lexer (.l) file 
